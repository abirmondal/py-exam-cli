CST101 - Computer Science Fundamentals Exam
============================================

INSTRUCTIONS:
1. Read all questions carefully
2. Complete your solutions in the provided *_solution.py files
3. Answer multiple choice questions in answers.txt
4. When finished, run: ./submit.sh

Files to Submit:
- problem1_solution.py
- problem2_solution.py
- answers.txt

DO NOT modify question files.

Time Limit: 2 hours
Total Points: 100

Good Luck!
