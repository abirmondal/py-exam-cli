# Problem 1: Hello World
# Write your solution here

def main():
    # Your code here
    pass

if __name__ == "__main__":
    main()
