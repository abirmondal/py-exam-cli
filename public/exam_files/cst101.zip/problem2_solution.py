# Problem 2: Calculate Sum
# Write your solution here

def calculate_sum(a, b):
    # Your code here
    pass

if __name__ == "__main__":
    print(calculate_sum(5, 3))
