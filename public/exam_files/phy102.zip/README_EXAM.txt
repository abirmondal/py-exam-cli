PHY102 - Physics Fundamentals Exam
===================================

INSTRUCTIONS:
1. Read all questions carefully
2. Complete your solutions in the provided files
3. Answer multiple choice questions in answers.txt
4. When finished, run: ./submit.sh

Time Limit: 2 hours
Total Points: 100

Good Luck!
