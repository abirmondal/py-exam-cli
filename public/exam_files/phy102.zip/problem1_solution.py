# Problem 1: Calculate Velocity
def calculate_velocity(distance, time):
    # Your code here
    pass
